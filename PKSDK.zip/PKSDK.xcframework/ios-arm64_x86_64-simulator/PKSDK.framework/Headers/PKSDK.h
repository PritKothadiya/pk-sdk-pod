//
//  PKSDK.h
//  PKSDK
//
//  Created by Prit Kothadiya on 11/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for PKSDK.
FOUNDATION_EXPORT double PKSDKVersionNumber;

//! Project version string for PKSDK.
FOUNDATION_EXPORT const unsigned char PKSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PKSDK/PublicHeader.h>


